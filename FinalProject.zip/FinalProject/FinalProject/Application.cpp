#include "Application.h"

Application::Application()
{
	angle = 0;

	// Camera parameters
	screenWidth = 1500;
	cameraPos = glm::vec3(-25.0f, 6.0f, 19.9f);
	cameraFront = glm::vec3(0.0f, 0.0f, 0.0f);
	cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
	yaw = 0.0f;
	pitch = 0.0f;
	firstMouse = true;
	lastX = 400.0;
	lastY = 300.0;
	sensitivity = 0.1f;
}

Application::~Application()
{
}

void Application::setupPerspective()
{
	// Pass perspective projection matrix
	glm::mat4 projection = glm::perspective(45.0f, (GLfloat)this->screenWidth / (GLfloat)this->screenHeight, 0.1f, 100.0f);
	shader->setMat4("projection", projection);
}

void Application::setupCamera()
{
	// LookAt camera (position, target/direction, up)
	viewPos = glm::vec3(20, 2, 0);
	glm::mat4 view = glm::lookAt(viewPos, glm::vec3(0, 0, 0), glm::vec3(0, 1, 0));
	shader->setMat4("view", view);
}

void Application::setupLighting()
{
	// set lighting attributes
	glm::vec3 lightPos = glm::vec3(0, 8, 19.9);
	shader->setVec3("lightPos", lightPos);
	shader->setVec3("viewPos", viewPos);
	glm::vec3 lightColor = glm::vec3(1.0f, 1.0f, 1.0f);
	shader->setVec3("lightColor", lightColor);
}

void Application::Init()
{
	// Build a lighting map shader
	shader = new Shader("cube.vert", "cube.frag");
	shader->Init();
	// Create instance of cube
	cube = new Cube(shader);
	cube->Init();
	cube->SetRotation(0, 0, 1, 0);

	// setup perspective 
	setupPerspective();
	// setup camera
	setupCamera();
	// setup lighting
	setupLighting();
}

void Application::DeInit()
{
	delete cube;
}

void Application::Update(double deltaTime)
{
	glm::vec3 cameraTarget = cameraPos + cameraFront;
	glm::mat4 view = glm::lookAt(cameraPos, cameraTarget, cameraUp);
	shader->setMat4("view", view);

	angle += (float)((deltaTime * 0.5f) / 1000);
	//cube->SetRotation(angle, 0, 1, 0);
}

void Application::Render()
{
	glViewport(0, 0, this->screenWidth, this->screenHeight);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	SetBackgroundColor(135, 206, 235);

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	glEnable(GL_DEPTH_TEST);

	//Tiang kiri gawang home
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.0f, 0.0f);
	cube->SetScale(0.2f, 1.75f, 0.2f);
	cube->Draw();

	//Tiang kanan gawang home
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.0f, 0.0f);
	cube->SetScale(0.2f, 1.75f, 0.2f);
	cube->Draw();

	//Tiang atas gawang home
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(0.0f, 0.9f, 0.0f);
	cube->SetScale(2.5f, 0.2f, 0.2f);
	cube->Draw();

	//Tiang bawah Kiri gawang home
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, -0.8f, -0.78f);
	cube->SetScale(0.2f, 0.2f, -1.75f);
	cube->Draw();

	//Tiang bawah Kanan gawang home
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, -0.8f, -0.78f);
	cube->SetScale(0.2f, 0.2f, -1.75f);
	cube->Draw();

	//Tiang bawah gawang home
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(0.0f, -0.8f, -1.65f);
	cube->SetScale(2.5f, 0.2f, 0.2f);
	cube->Draw();

	//Tiang miring kiri gawang home
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, -0.6f, -1.55f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, -0.4f, -1.35f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, -0.2f, -1.15f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.0f, -0.95f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.2f, -0.75f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.4f, -0.55f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.6f, -0.35f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.8f, -0.15f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	//Tiang miring kanan gawang home
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, -0.6f, -1.55f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, -0.4f, -1.35f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, -0.2f, -1.15f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.0f, -0.95f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.2f, -0.75f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.4f, -0.55f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.6f, -0.35f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.8f, -0.15f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	//Tiang kiri gawang away
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.0f, 39.8f);
	cube->SetScale(0.2f, 1.75f, 0.2f);
	cube->Draw();

	//Tiang kanan gawang away
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.0f, 39.8f);
	cube->SetScale(0.2f, 1.75f, 0.2f);
	cube->Draw();

	//Tiang atas gawang away
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(0.0f, 0.9f, 39.8f);
	cube->SetScale(2.5f, 0.2f, 0.2f);
	cube->Draw();

	//Tiang bawah Kiri gawang away
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, -0.8f, 40.58f);
	cube->SetScale(0.2f, 0.2f, -1.75f);
	cube->Draw();

	//Tiang bawah kanan gawang away
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, -0.8f, 40.58f);
	cube->SetScale(0.2f, 0.2f, -1.75f);
	cube->Draw();

	//Tiang bawah gawang away
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(0.0f, -0.8f, 41.45f);
	cube->SetScale(2.5f, 0.2f, 0.2f);
	cube->Draw();

	//Tiang miring kiri gawang away
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, -0.6f, 41.35f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, -0.4f, 41.15f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, -0.2f, 40.95f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.0f, 40.75f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.2f, 40.55f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.4f, 40.35f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.6f, 40.15f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.25f, 0.8f, 39.95f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	//Tiang miring kanan gawang away
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, -0.6f, 41.35f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, -0.4f, 41.15f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, -0.2f, 40.95f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.0f, 40.75f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.2f, 40.55f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.4f, 40.35f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.6f, 40.15f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.25f, 0.8f, 39.95f);
	cube->SetScale(0.2f, 0.2f, 0.2f);
	cube->Draw();

	//Lapangan
	cube->SetColor(50.0f, 205.0f, 50.0f);
	cube->SetPosition(0.0f, -2.21f, 20.5f);
	cube->SetScale(35.0f, 2.5f, 45.0f);
	cube->Draw();

	//Garis lapangan 
	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(0.0f, -0.9f, 0.0f);
	cube->SetScale(30.0f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(0.0f, -0.9f, 39.8f);
	cube->SetScale(30.0f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(0.0f, -0.9f, 19.9f);
	cube->SetScale(30.0f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(15.0f, -0.9f, 19.9f);
	cube->SetScale(0.2f, 0.002f, 40.0f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(-15.0f, -0.9f, 19.9f);
	cube->SetScale(0.2f, 0.002f, 40.0f);
	cube->Draw();
	
	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(3.0f, -0.9f, 1.59f);
	cube->SetScale(0.2f, 0.002f, 3.0f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(3.0f, -0.9f, 38.31f);
	cube->SetScale(0.2f, 0.002f, 3.0f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(-3.0f, -0.9f, 1.59f);
	cube->SetScale(0.2f, 0.002f, 3.0f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(-3.0f, -0.9f, 38.31f);
	cube->SetScale(0.2f, 0.002f, 3.0f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(0.0f, -0.9f, 3.0f);
	cube->SetScale(6.0f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(0.0f, -0.9f, 36.8f);
	cube->SetScale(6.0f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(6.5f, -0.9f, 3.0f);
	cube->SetScale(0.2f, 0.002f, 6.0f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(6.5f, -0.9f, 36.9f);
	cube->SetScale(0.2f, 0.002f, 6.0f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(-6.5f, -0.9f, 3.0f);
	cube->SetScale(0.2f, 0.002f, 6.0f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(-6.5f, -0.9f, 36.9f);
	cube->SetScale(0.2f, 0.002f, 6.0f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(0.0f, -0.9f, 5.9f);
	cube->SetScale(13.1f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(255.0f, 255.0f, 255.0f);
	cube->SetPosition(0.0f, -0.9f, 34.0f);
	cube->SetScale(13.1f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-3.0f, -0.9f, 19.9f);
	cube->SetScale(0.2f, 0.002f, 1.0f);
	cube->Draw();

	//Lingkaran tengah away
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-3.0f, -0.9f, 19.9f);
	cube->SetScale(0.2f, 0.002f, 1.0f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.75f, -0.9f, 20.5f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.5f, -0.9f, 20.8f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.26f, -0.9f, 21.0f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.0f, -0.9f, 21.3f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.76f, -0.9f, 21.5f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.5f, -0.9f, 21.8f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();


	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(3.0f, -0.9f, 19.9f);
	cube->SetScale(0.2f, 0.002f, 1.0f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.75f, -0.9f, 20.5f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.5f, -0.9f, 20.8f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.26f, -0.9f, 21.0f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.0f, -0.9f, 21.3f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.76f, -0.9f, 21.5f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.5f, -0.9f, 21.8f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(0.0f, -0.9f, 22.0f);
	cube->SetScale(3.2f, 0.002f, 0.2f);
	cube->Draw();


	//Lingkaran tengah home
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.75f, -0.9f, 19.3f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.5f, -0.9f, 19.0f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.26f, -0.9f, 18.8f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.0f, -0.9f, 18.5f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.76f, -0.9f, 18.3f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.5f, -0.9f, 18.0f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();


	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.75f, -0.9f, 19.3f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.5f, -0.9f, 19.0f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.26f, -0.9f, 18.8f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.0f, -0.9f, 18.5f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.76f, -0.9f, 18.3f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.5f, -0.9f, 18.0f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(0.0f, -0.9f, 17.8f);
	cube->SetScale(3.2f, 0.002f, 0.2f);
	cube->Draw();

	//Tiang corner home kiri
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-15.0f, -0.4f, 0.0f);
	cube->SetScale(0.2f, 1.0f, 0.2f);
	cube->Draw();

	//Tiang corner home kanan
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(15.0f, -0.4f, 0.0f);
	cube->SetScale(0.2f, 1.0f, 0.2f);
	cube->Draw();

	//Tiang corner away kiri
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-15.0f, -0.4f, 39.8f);
	cube->SetScale(0.2f, 1.0f, 0.2f);
	cube->Draw();

	//Tiang corner home kiri
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(15.0f, -0.4f, 39.8f);
	cube->SetScale(0.2f, 1.0f, 0.2f);
	cube->Draw();

	//lingkaran kotak pinalti home
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.5f, -0.9f, 6.1f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.26f, -0.9f, 6.4f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.0f, -0.9f, 6.7f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.76f, -0.9f, 6.9f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.5f, -0.9f, 7.1f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();


	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.5f, -0.9f, 6.1f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.26f, -0.9f, 6.4f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.0f, -0.9f, 6.7f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.76f, -0.9f, 6.9f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.5f, -0.9f, 7.1f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(0.0f, -0.9f, 7.3f);
	cube->SetScale(3.2f, 0.002f, 0.2f);
	cube->Draw();

	//lingkaran kotak pinalti away
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.5f, -0.9f, 33.8f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.26f, -0.9f, 33.5f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-2.0f, -0.9f, 33.2f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.76f, -0.9f, 33.0f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(-1.5f, -0.9f, 32.8f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();


	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.5f, -0.9f, 33.8f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.26f, -0.9f, 33.5f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(2.0f, -0.9f, 33.2f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.76f, -0.9f, 33.0f);
	cube->SetScale(0.7f, 0.002f, 0.2f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(1.5f, -0.9f, 32.8f);
	cube->SetScale(0.2f, 0.002f, 0.5f);
	cube->Draw();

	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(0.0f, -0.9f, 32.6f);
	cube->SetScale(3.2f, 0.002f, 0.2f);
	cube->Draw();

	//Titik pinalty home
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(0.0f, -0.9f, 4.4f);
	cube->SetScale(0.2f, 0.02f, 0.2f);
	cube->Draw();

	//Titik pinallty away
	cube->SetColor(250.0f, 235.0f, 215.0f);
	cube->SetPosition(0.0f, -0.9f, 35.4f);
	cube->SetScale(0.2f, 0.02f, 0.2f);
	cube->Draw();

	glDisable(GL_DEPTH_TEST);

}

void Application::ProcessInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
	const float cameraSpeed = 0.05f;
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		cameraPos += cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		cameraPos -= cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;

	// Handle camera rotation using mouse input
	double xpos, ypos;
	glfwGetCursorPos(window, &xpos, &ypos);

	if (firstMouse) {
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

	lastX = xpos;
	lastY = ypos;

	xoffset *= sensitivity;
	yoffset *= sensitivity;

	yaw += xoffset;
	pitch += yoffset;

	// Clamp pitch to prevent flipping
	if (pitch > 89.0f)
		pitch = 89.0f;
	if (pitch < -89.0f)
		pitch = -89.0f;

	// Update camera front direction
	glm::vec3 front;
	front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	front.y = sin(glm::radians(pitch));
	front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	cameraFront = glm::normalize(front);
}


int main(int argc, char** argv) {
	Application app = Application();
	app.Start("Cube Example",
		1366, 768,
		false,
		false);
}