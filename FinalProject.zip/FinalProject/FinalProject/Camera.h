#pragma once
class Camera
{
public:

private:

};

